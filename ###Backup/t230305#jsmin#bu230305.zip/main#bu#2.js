const fs = require('node:fs');





const strCode = fs.readFileSync('test.js', {encoding: 'utf8', flag: 'r'});;


/**
 * 한줄주석 제거
 * @param {string} tx
 * @returns
 */
const fn_clearCommentsOneLine = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^[ \t]*\/\/[^\r\n]*$/;
    if (rex.test(ls) === true)
        return '';
    else
        return ls;
};

/**
 * 다중주석 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineAll = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*[\S\s]*?\*\//g;
    const rv = ls.replaceAll(rex, '').trim();
    return rv;
};

/**
 * 다중주석 시작점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineBegin = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*.*?$/;
    const tm = ls.match(rex);
    if (Array.isArray(tm) && (tm.length > 0)) {
        const rv = ls.replace(tm[0], '').trim();
        bcm = true;
        return rv;
    }
    else
        return ls;
};

/**
 * 다중주석 끝점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineEnd = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^.*?\*\//;
    const tm = ls.match(rex);
    if (tm !== null) {
        const rv = ls.replace(tm[0], '').trim();
        bcm = false;
        return rv;
    }
    else
        return '';
};

const rlst = [];
let bcm = false;
const lsa = strCode.trim().split(/\r?\n/);
if (Array.isArray(lsa) && (lsa.length > 0)) {
    let ls = '';
    for (ls of lsa) {
        ls = ls.trim();
        ls = fn_clearCommentsOneLine(ls);
        ls = fn_clearCommentsMultiLineAll(ls);
        if (ls.startsWith('const fn_checkComments')) {
            console.log('');
        }
        if (bcm === false)
            ls = fn_clearCommentsMultiLineBegin(ls);
        else
            ls = fn_clearCommentsMultiLineEnd(ls);
        if (ls !== '') {
            console.log(ls);
            rlst.push(ls);
        }
    }
}

console.log('');
console.log('');
console.log('');

fs.writeFileSync('test.dist.js', rlst.join('\n'));












// const readline = require('node:readline');
// const rl = readline.createInterface({
//   input: process.stdin,
//   output: process.stdout,
//   prompt: 'OHAI> ',
// });

// rl.prompt();

// rl.on('line', (line) => {
//   switch (line.trim()) {
//     case 'hello':
//       console.log('world!');
//       break;
//     default:
//       console.log(`Say what? I might have heard '${line.trim()}'`);
//       break;
//   }
//   rl.prompt();
// }).on('close', () => {
//   console.log('Have a great day!');
//   process.exit(0);
// });