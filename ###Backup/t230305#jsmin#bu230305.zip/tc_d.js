'use strict';
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const fn_checkComments = (ts) => {
const rex = /^[ \t]*\/\/[^\r\n]*$/;
return rex.test(ts);
};
const fn_checkRegion = (ts) => {
return ts.startsWith('//#region ') || ts.startsWith('//#endregion ');
};
const fn_afterClearComments = (rstr) => {
const rex = /\/\*[^\*\/]*\*\//gm;
return rstr.replaceAll(rex, '');
};
const _rlst = [`
`.trim()];
const fn_work = async (ip) => {
try {
const ifp = ip;
fs.accessSync(ifp);
const rl = readline.createInterface({
input: fs.createReadStream(ifp),
crlfDelay: Infinity,
});
for await (const ls of rl) {
const ts = ls.trim();
if (ts === '') continue;
if (fn_checkComments(ts) || fn_checkRegion(ts)) { }
else {
_rlst.push(ts);
}
}
}
catch (e) {
console.log(`# Error  ${e}`);
}
};
const fn_entry = async (ta) => {
const ipa = ta;
for (const ip of ipa) {
await fn_work(ip);
}
if (_rlst.length > 0) {
const rstr = fn_afterClearComments(_rlst.join('\n'));
const op = path.resolve(__dirname, '../js/hflib.js');
fs.writeFileSync(op, rstr, {encoding: 'utf8'});
}
}
const ipa = [
path.resolve(__dirname, 'hfCommon.js'),
path.resolve(__dirname, 'hfCountTask.js'),
path.resolve(__dirname, 'hfTween.js'),
path.resolve(__dirname, 'hfWeich.js'),
];
fn_entry(ipa);