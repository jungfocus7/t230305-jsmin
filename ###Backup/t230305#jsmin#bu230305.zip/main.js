const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const readline = require('node:readline');





/**
 * 한줄주석 제거
 * @param {string} tx
 * @returns
 */
const fn_clearCommentsOneLine = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^[ \t]*\/\/[^\r\n]*$/;
    if (rex.test(ls) === true)
        return '';
    else
        return ls;
};

/**
 * 다중주석 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineAll = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*[\S\s]*?\*\//g;
    const rv = ls.replaceAll(rex, '').trim();
    return rv;
};

/**
 * 다중주석 시작점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineBegin = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*.*?$/;
    const tm = ls.match(rex);
    if (Array.isArray(tm) && (tm.length > 0)) {
        const rv = ls.replace(tm[0], '').trim();
        gd.bcm = true;
        return rv;
    }
    else
        return ls;
};

/**
 * 다중주석 끝점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineEnd = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^.*?\*\//;
    const tm = ls.match(rex);
    if (tm !== null) {
        const rv = ls.replace(tm[0], '').trim();
        gd.bcm = false;
        return rv;
    }
    else
        return '';
};


// const frs = fs.createReadStream('tb.js');
// const fws = fs.createWriteStream('tb.dist.js');
// const rl = readline.createInterface({
//     input: frs,
//     crlfDelay: Infinity
// });


/** 글로벌 데이터 오브젝트 */
const gd = Object.seal({
    eol: os.EOL,
    ifp: '', ofp: '',
    frs: null, fws: null,
    rl: null,
    bcm: false,
    bf: true
});


/**
 * 핵심 작업
 * @param {string} ip
 * @param {string} op
 */
const fn_work = async (ip, op) => {
    try {
        gd.ifp = ip;
        gd.ofp = op;
        fs.accessSync(gd.ifp);

        gd.frs = fs.createReadStream(gd.ifp);
        gd.fws = fs.createWriteStream(gd.ofp);
        gd.rl = readline.createInterface({
            input: gd.frs,
            crlfDelay: Infinity
        });

        for await (let ls of gd.rl) {
            ls = ls.trim();
            if (ls === '') continue;
            ls = fn_clearCommentsOneLine(ls);
            ls = fn_clearCommentsMultiLineAll(ls);
            if (gd.bcm === false)
                ls = fn_clearCommentsMultiLineBegin(ls);
            else
                ls = fn_clearCommentsMultiLineEnd(ls);
            if (ls !== '') {
                console.log(ls);
                // gd.fws.write(`>>> ${ls}\n`);
                if (gd.bf === true) {
                    gd.fws.write(ls);
                    gd.bf = false;
                }
                else
                    gd.fws.write('\n' + ls);
            }
        }
    }
    catch (e) {
        console.log(`# Error  ${e}`);
    }
};

fn_work(path.resolve(__dirname, 'tc.js'),
    path.resolve(__dirname, 'tc_d.js'));


