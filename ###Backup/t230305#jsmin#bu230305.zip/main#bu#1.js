const strCode = `
RegExr was /*created by gskinner.com.
Edit the Expression & Text to see matches.*/ Roll over matches or the expression for details. PCRE & JavaScript flavors of RegEx are supported. Validate your expression with Tests mode.
The side bar includes a Cheatsheet, full Reference, and Help. You can also Save & Share with the Community /*and view patterns you create or favorite*/ in My Patterns.
Explore /**results with the*/ Tools below. Replace & /*List output custom*/ results. Details lists capture groups. Explain describes your expression in plain English.

// ### lastest update 230304
// The MIT License (MIT)
// Copyright (c) 2023-present jungfocus7
export const hfnum = Object.seal({
/**
* 넘버가 맞는지 확인
* @param {number} tv
* @returns boolean
*/
IsNumber: (tv) => {
return typeof tv === 'number';
},
`;
// const tx = 'Explore/** results with the */Tools below. Replace &/* List output custom */results. Details lists capture groups. Explain describes your expression in plain English.'
//     .replaceAll(/\/\*[\S\s]*?\*\//g, '');
// console.log(tx);

/**
 * 한줄주석 제거
 * @param {string} tx
 * @returns
 */
const fn_clearCommentsOneLine = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^[ \t]*\/\/[^\r\n]*$/;
    if (rex.test(ls) === true)
        return '';
    else
        return ls;
};

/**
 * 다중주석 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineAll = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*[\S\s]*?\*\//g;
    const rv = ls.replaceAll(rex, '').trim();
    return rv;
};

/**
 * 다중주석 시작점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineBegin = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*.*?$/;
    const tm = ls.match(rex);
    if (Array.isArray(tm) && (tm.length > 0)) {
        const rv = ls.replace(tm[0], '').trim();
        bcm = true;
        return rv;
    }
    else
        return ls;
};

/**
 * 다중주석 끝점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineEnd = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^.*?\*\//;
    const tm = ls.match(rex);
    if (tm !== null) {
        const rv = ls.replace(tm[0], '').trim();
        bcm = false;
        return rv;
    }
    else
        return '';
};


let bcm = false;
const lsa = strCode.trim().split('\n');
if (Array.isArray(lsa) && (lsa.length > 0)) {
    let ls = '';
    for (ls of lsa) {
        ls = ls.trim();
        ls = fn_clearCommentsOneLine(ls);
        ls = fn_clearCommentsMultiLineAll(ls);
        if (ls.startsWith('* 넘버가 맞는지 확인')) {
            // console.log('');
        }
        if (bcm === false)
            ls = fn_clearCommentsMultiLineBegin(ls);
        else
            ls = fn_clearCommentsMultiLineEnd(ls);
        if (ls !== '') {
            console.log(ls);
        }
    }
}

console.log('');
console.log('');
console.log('');












// const readline = require('node:readline');
// const rl = readline.createInterface({
//   input: process.stdin,
//   output: process.stdout,
//   prompt: 'OHAI> ',
// });

// rl.prompt();

// rl.on('line', (line) => {
//   switch (line.trim()) {
//     case 'hello':
//       console.log('world!');
//       break;
//     default:
//       console.log(`Say what? I might have heard '${line.trim()}'`);
//       break;
//   }
//   rl.prompt();
// }).on('close', () => {
//   console.log('Have a great day!');
//   process.exit(0);
// });