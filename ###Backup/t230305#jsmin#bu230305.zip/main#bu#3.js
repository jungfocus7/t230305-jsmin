// const os = require('node:os');
const fs = require('node:fs');
const readline = require('node:readline');
// const tx = os.EOL;





/**
 * 한줄주석 제거
 * @param {string} tx
 * @returns
 */
const fn_clearCommentsOneLine = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^[ \t]*\/\/[^\r\n]*$/;
    if (rex.test(ls) === true)
        return '';
    else
        return ls;
};

/**
 * 다중주석 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineAll = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*[\S\s]*?\*\//g;
    const rv = ls.replaceAll(rex, '').trim();
    return rv;
};

/**
 * 다중주석 시작점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineBegin = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /\/\*.*?$/;
    const tm = ls.match(rex);
    if (Array.isArray(tm) && (tm.length > 0)) {
        const rv = ls.replace(tm[0], '').trim();
        bcm = true;
        return rv;
    }
    else
        return ls;
};

/**
 * 다중주석 끝점 제거
 * @param {string} ls
 * @returns
 */
const fn_clearCommentsMultiLineEnd = (ls) => {
    if ((typeof ls !== 'string') || (ls === '')) return '';
    const rex = /^.*?\*\//;
    const tm = ls.match(rex);
    if (tm !== null) {
        const rv = ls.replace(tm[0], '').trim();
        bcm = false;
        return rv;
    }
    else
        return '';
};


const frs = fs.createReadStream('tb.js');
const fws = fs.createWriteStream('tb.dist.js');
const rl = readline.createInterface({
    input: frs,
    crlfDelay: Infinity
});


let bcm = false;

rl.on('line', (ls) => {
    ls = ls.trim();
    ls = fn_clearCommentsOneLine(ls);
    ls = fn_clearCommentsMultiLineAll(ls);
    if (bcm === false)
        ls = fn_clearCommentsMultiLineBegin(ls);
    else
        ls = fn_clearCommentsMultiLineEnd(ls);
    if (ls !== '') {
        console.log(ls);
        // fws.write(`>>> ${ls}\n`);
        fws.write(ls + '\n');
    }
}).on('close', () => {
    frs.close();
    fws.close();
    process.exit(0);
});
